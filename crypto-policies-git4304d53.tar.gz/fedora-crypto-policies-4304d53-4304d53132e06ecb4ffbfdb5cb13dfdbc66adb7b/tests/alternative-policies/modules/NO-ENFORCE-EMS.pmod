__ems = RELAX
